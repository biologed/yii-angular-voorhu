<?php

namespace app\controllers;

use app\models\Users;

use SebastianBergmann\CodeCoverage\Report\PHP;
use Yii;
use yii\base\InvalidRouteException;
use yii\db\DataReader;
use yii\db\Exception;
use yii\filters\Cors;
use yii\helpers\ArrayHelper;
use yii\rest\ActiveController;
use yii\web\IdentityInterface;
use yii\web\Response;
use app\web\User;
use yii\web\NotFoundHttpException;
use yii\web\ErrorAction;
use yii\captcha\CaptchaAction;

class AuthController extends ActiveController
{
    public $modelClass = Users::class;
    public $enableCsrfValidation = false;

    public function behaviors(): array
    {
        return ArrayHelper::merge(parent::behaviors(), [
            'corsFilter' => [
                'class' => Cors::className(),
                'cors' => [],
                'actions' => [
                    'incoming' => [
                        'Origin' => ['*'],
                        'Access-Control-Request-Method' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS'],
                        'Access-Control-Request-Headers' => ['*'],
                        'Access-Control-Allow-Credentials' => null,
                        'Access-Control-Max-Age' => 86400,
                        'Access-Control-Expose-Headers' => [],
                    ],
                ],
            ],
        ]);
    }

    public function actions(): array
    {
        return [
            'error' => [
                'class' => ErrorAction::class,
            ],
            'captcha' => [
                'class' => CaptchaAction::class,
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * @throws NotFoundHttpException
     */
    public function actionLogin(): array
    {
        \Yii::info("actionLogin");

        $request = Yii::$app->request;
        $username = $request->getBodyParam('username');
        $password = $request->getBodyParam('password');

        if (!isset($username, $password)) {
            throw new NotFoundHttpException('Please enter the username and password.');
        }

        $user = Users::findOne(['username' => $username]);

        if (!$user) {
            throw new NotFoundHttpException('User not found.');
        }

        if (!Yii::$app->getSecurity()->validatePassword($password, $user->password)) {
            throw new NotFoundHttpException('Incorrect password.');
        }

        if ($user->status === Users::STATUS_ACTIVE) {
            Yii::$app->user->login($user);
            Yii::$app->session->setFlash('success', 'Your account has been authorised.');
            return [
                'code' => '1',
                'status' => 200,
                'message' => 'success',
                'name' => "Login",
            ];
        }

        if ($user->status === Users::STATUS_INACTIVE) {
            throw new NotFoundHttpException('You need to activate your account.');
        }

        throw new NotFoundHttpException('Unhandled error.');
    }

    /**
     * @throws InvalidRouteException
     */
    public function actionLogout(): array
    {
        Yii::info("actionLogout");

        Yii::$app->user->logout();

        return [
            'code' => '1',
            'status' => 200,
            'message' => 'success',
            'name' => "Logout",
        ];
    }

    /**
     * @throws Exception
     * @throws \yii\base\Exception
     * @throws NotFoundHttpException
     */
    public function actionRegister(): array
    {
        Yii::info("actionRegister");

        $request = Yii::$app->request;
        $username = $request->getBodyParam('username');
        $email = $request->getBodyParam('email');
        $password = Yii::$app->getSecurity()->generatePasswordHash($request->getBodyParam('password'));
        $activateToken = trim(Yii::$app->security->generateRandomString(), '-');

        $user = Users::find()->where(['email' => $email])->orWhere(['username' => $username])->one();

        if ($user) {
            if ($user->username === $username) {
                throw new NotFoundHttpException('Account with this username is already registered.');
            }
            if ($user->email === $email) {
                throw new NotFoundHttpException('Account with this email is already registered.');
            }
            throw new NotFoundHttpException('Account already registered.');
        }

        Yii::$app->db->createCommand()->insert('ads_users', [
            'email' => $email,
            'username' => $username,
            'password' => $password,
            'activateToken' => $activateToken,
        ])->execute();

        Yii::$app->mailer->compose()
            ->setFrom(['super.gird2012@yandex.ru' => 'voorhu.com'])
            ->setTo($email)
            ->setSubject('Account activation')
            ->setTextBody('Please activate your account by clicking the following link: ' . Yii::$app->urlManager->createAbsoluteUrl(['auth/activate', 'token' => $activateToken]))
            ->send();

        //TODO перевести на рельсы модели
//        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
//            $model->status = Users::STATUS_INACTIVE;
//            $model->activate_token = Yii::$app->security->generateRandomString();
//
//            if ($model->save()) {
//                if ($model->sendActivationEmail()) {
//                    Yii::$app->session->setFlash('success', 'Please check your email for activation instructions.');
//                    return 0;
//                } else {
//                    Yii::$app->session->setFlash('error', 'Failed to send activation email. Please try again later.');
//                }
//            } else {
//                Yii::$app->session->setFlash('error', 'Failed to register. Please try again later.');
//            }
//        }

        Yii::$app->response->format = Response::FORMAT_JSON;
        return [
            'code' => '1',
            'status' => 200,
            'message' => 'На указанную почту отправлено письмо со ссылкой на активацию аккаунта',
            'name' => "Registration",
        ];
    }

    /**
     * @throws InvalidRouteException
     * @throws NotFoundHttpException
     */
    public function actionActivate($token): void
    {
        Yii::info("actionActivate");

        $user = Users::findOne(['activateToken' => $token]);
//        if ($user->status === 1) {
//            throw new NotFoundHttpException('Your account has already been activated.');
//        }
        if (!$user) {
            throw new NotFoundHttpException('Invalid activation token.');
        }

        $user->status = Users::STATUS_ACTIVE;
        $user->save();

        Yii::$app->session->setFlash('onActivation', "Аккаунт был успешно активирован.");

        Yii::$app->user->login($user);

        Yii::$app->response->redirect('/', 301)->send();
    }

    public function actionStatus(): array
    {
        return [
            'code' => '1',
            'status' => 200,
            'message' => Yii::$app->user->identity->status ?? 0,
            'name' => "Status",
        ];
    }
}
