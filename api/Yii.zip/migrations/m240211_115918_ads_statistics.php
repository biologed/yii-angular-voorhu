<?php

use yii\db\Migration;

/**
 * Class m240211_115918_ads_statistics
 */
class m240211_115918_ads_statistics extends Migration
{
    /**
     * {@inheritdoc}
     * @throws \yii\db\Exception
     */
    public function safeUp()
    {
        $tableOptions = null;

        $this->createTable('ads_stats', [
            'id' => $this->primaryKey(),
            'appId' => $this->string()->notNull(),
            'appType' => $this->smallInteger()->notNull()->defaultValue(1),
            'timesCalled' => $this->smallInteger()->notNull()->defaultValue(1),
            'createdAt' => $this->dateTime()->notNull()->defaultExpression('CURRENT_TIMESTAMP'),
            'isDeleted' => $this->smallInteger()->notNull()->defaultValue(0),
        ], $tableOptions);

        // creates index for column `author_id`
        $this->createIndex(
            'idx-ads-stats-appid',
            'ads_stats',
            'appId'
        );


        $insert = [
            [
                'appId' => 'com-YourCompany-Test001',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-7 11:06:38'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-5-6 09:16:19'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-5-6 09:15:45'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-5-6 09:11:09'
            ],
            [
                'appId' => 'com-YourCompany-ADSCoreLite',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 17:29:57'
            ],
            [
                'appId' => 'com-YourCompany-ADSCoreLite',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 17:29:52'
            ],
            [
                'appId' => 'com-YourCompany-Test001',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 15:29:51'
            ],
            [
                'appId' => 'com-YourCompany-Test001',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 14:39:23'
            ],
            [
                'appId' => 'com-fazenda-Seabattle',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 14:37:37'
            ],
            [
                'appId' => 'com-YourCompany-Test001',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 14:23:40'
            ],
            [
                'appId' => 'com-YourCompany-Test001',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 14:19:35'
            ],
            [
                'appId' => 'com-fazenda-Seabattle',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 13:24:20'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:55:28'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:55:23'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:55:07'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:55:04'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:54:47'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:54:31'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:54:14'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '4',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:53:37'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '6',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:53:11'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '6',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:52:57'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:46:52'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 09:30:22'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-5-2 08:49:42'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-27 01:23:46'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '6',
                'timesCalled' => '1',
                'createdAt' => '2024-4-27 01:23:36'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '6',
                'timesCalled' => '1',
                'createdAt' => '2024-4-27 00:56:29'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 23:32:08'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 23:31:53'
            ],
            [
                'appId' => 'com-YourCompany-MyProject2',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 23:00:41'
            ],
            [
                'appId' => 'com-YourCompany-MyProject2',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 23:00:40'
            ],
            [
                'appId' => 'com-YourCompany-MyProject2',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 23:00:29'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 21:09:34'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 21:01:44'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:59:06'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:53:30'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:52:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:51:39'
            ],
            [
                'appId' => 'com-YourCompany-MyProject2',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:38:26'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:33:09'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:21:49'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:21:00'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:09:33'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:07:55'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:05:12'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:03:26'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:02:25'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:01:46'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 20:00:49'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:57:21'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:57:15'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:56:05'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:55:54'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:54:56'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:54:23'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:51:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:49:05'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:49:00'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:48:55'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:47:54'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:47:34'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 19:31:49'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:41:20'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:41:19'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:41:18'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:41:14'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:26:59'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:26:54'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:21:51'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:21:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:21:40'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:14:33'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:14:31'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:13:53'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:05:44'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 18:05:33'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 17:51:11'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 17:51:11'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 17:51:00'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 17:50:47'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 17:24:02'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 17:23:58'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 16:15:53'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 16:15:53'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 16:15:47'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 16:15:40'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 14:53:35'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '6',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 14:53:29'
            ],
            [
                'appId' => 'com-fazenda-Seabattle',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 12:44:01'
            ],
            [
                'appId' => 'com-fazenda-Seabattle',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 12:43:37'
            ],
            [
                'appId' => 'com-fazenda-Seabattle',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 12:43:17'
            ],
            [
                'appId' => 'com-fazenda-Seabattle',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-26 12:28:33'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-12 23:11:02'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-4-12 21:42:33'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-4-12 21:41:19'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-4-12 21:39:35'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-4-12 14:00:49'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-4-11 10:54:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 15:42:57'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 15:42:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 14:08:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 14:04:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 13:37:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 12:53:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 12:47:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 12:45:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 12:42:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 12:37:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 12:30:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 10:34:39'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 06:41:03'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 06:40:40'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 06:35:15'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 06:32:39'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 06:31:59'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 06:31:26'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '2',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 06:30:58'
            ],
            [
                'appId' => 'com-dude-vibor',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 04:17:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 03:02:42'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-26 01:10:08'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-25 23:49:58'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-25 22:49:21'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-25 19:33:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-25 17:11:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-25 16:52:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-25 13:35:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-25 10:44:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-24 23:27:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-24 16:22:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-24 16:02:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-24 15:59:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-24 13:24:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-24 08:09:23'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 23:09:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 15:47:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 09:57:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 07:44:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 04:34:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 01:30:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 01:19:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 01:16:07'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-23 00:00:12'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:59:58'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:59:44'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:59:23'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:59:09'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:58:55'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:58:42'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:58:04'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:57:42'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:57:20'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:57:12'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 23:57:01'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 22:38:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 18:42:24'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 18:35:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 14:39:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 14:32:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 13:38:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 13:36:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 13:33:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 12:05:00'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:24:45'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:24:35'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:24:30'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:24:24'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:24:13'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:24:08'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:23:59'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:23:53'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:23:49'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:23:39'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:23:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 10:09:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 04:45:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-22 01:39:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 21:03:04'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 21:02:33'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 20:12:44'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 17:00:36'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 17:00:30'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 17:00:24'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 17:00:18'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 17:00:10'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 17:00:04'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:59:59'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:59:52'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:59:41'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:59:31'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:58:01'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:33:18'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:33:12'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:33:04'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:57'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:46'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:40'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:31'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:25'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:19'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:11'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:32:02'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 16:31:46'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 15:35:02'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 15:34:56'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 15:34:39'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 15:33:57'
            ],
            [
                'appId' => 'com-hardworkers-cyberball2120',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 15:33:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 10:29:40'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 09:54:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 09:37:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 09:33:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 09:30:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 09:26:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 09:23:32'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-21 03:07:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 21:31:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 20:59:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 20:49:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 20:46:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 20:43:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 20:40:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 18:55:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 15:42:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 15:39:00'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 15:24:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 14:07:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 13:20:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 13:17:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 13:14:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 12:08:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 12:05:11'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 10:18:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 09:47:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 08:22:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 08:19:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 01:45:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 01:42:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 01:39:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 01:36:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-20 00:36:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-19 22:31:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-19 22:28:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-19 22:25:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-19 21:07:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-19 10:03:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-19 10:00:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-18 22:40:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-18 21:24:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-18 19:36:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-18 17:21:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-18 11:57:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 23:43:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 19:45:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 19:42:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 18:57:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 18:32:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 15:30:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 15:27:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 15:18:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 15:08:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 15:05:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 14:58:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 14:56:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 14:55:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 14:25:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 12:40:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 12:34:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 12:30:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 12:26:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 12:23:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 10:48:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 10:38:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 10:24:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 09:39:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 09:27:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 09:24:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 03:55:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 03:52:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 03:49:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-17 03:46:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 23:39:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 23:35:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 23:15:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 23:12:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 23:07:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 19:51:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 19:51:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 19:51:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 19:48:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 19:45:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 19:09:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 18:25:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 18:08:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 17:08:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 17:03:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 16:48:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 16:19:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 16:15:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 16:12:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 14:58:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 14:54:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 11:41:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 11:31:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 10:47:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 10:39:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 09:18:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 09:14:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 09:11:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 08:56:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 08:50:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-16 08:02:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 23:27:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 21:12:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:53:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:50:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:47:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:43:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:40:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:36:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:29:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:26:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 20:23:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 19:46:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 18:55:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 18:19:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 18:14:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 18:10:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 18:06:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 18:06:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 18:03:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 17:59:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 17:55:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 17:53:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 17:52:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 17:13:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 17:09:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 15:15:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 14:27:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 13:17:41'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 11:39:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 10:26:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 07:03:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 05:35:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 05:35:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 05:35:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-15 02:36:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 20:39:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 20:35:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 20:32:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 20:29:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 19:16:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 09:49:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 09:45:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 09:08:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 06:11:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 01:10:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 01:09:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 01:06:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 00:13:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-14 00:12:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 20:42:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 20:20:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 20:15:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 19:42:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 19:23:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 19:19:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 19:15:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 19:09:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 19:02:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 18:59:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 15:15:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 12:37:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 12:34:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 12:31:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 11:47:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-13 11:47:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 20:35:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 19:04:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 17:47:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 17:14:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 04:00:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 03:56:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 01:19:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 01:16:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 01:13:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-12 01:09:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 21:06:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 21:03:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 18:24:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 17:15:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 14:03:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 13:07:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 13:03:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 12:59:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 08:36:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 08:25:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 08:22:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 08:01:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 07:44:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 05:35:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 02:27:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 01:15:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 01:12:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 01:09:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 00:22:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 00:18:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-11 00:15:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 23:09:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 23:06:34'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:59'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:53'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:43'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:39'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:38'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:38'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:38'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:35'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:59:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:52:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 21:48:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 19:55:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 18:35:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 17:51:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 16:23:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 16:23:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 16:15:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 14:25:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 14:25:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 14:21:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 14:18:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 14:15:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 13:31:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 13:25:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 12:52:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 12:49:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 12:20:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 10:16:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 10:12:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 10:08:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 10:05:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 10:01:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 09:57:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 09:23:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 09:20:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 09:17:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 09:13:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 09:10:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 09:03:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 08:59:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 08:56:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 07:33:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 07:30:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 07:26:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 07:23:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 06:43:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 06:42:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 04:50:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 04:47:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 04:26:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 04:24:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 04:07:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-10 02:54:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 21:53:26'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 21:43:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 17:31:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 17:02:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 13:52:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 13:50:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 10:37:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 10:32:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 09:52:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 09:49:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 09:46:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 09:45:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 09:41:50'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 08:37:05'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 08:34:54'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 08:31:52'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 08:27:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 07:40:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 07:37:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 07:37:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 07:34:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 07:31:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 01:27:55'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 00:57:15'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 00:57:12'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 00:57:07'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-9 00:49:52'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 22:53:12'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 22:53:11'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 22:53:10'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 22:53:08'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 21:36:39'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 21:36:38'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 21:36:38'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 21:36:38'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 21:36:37'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 21:36:36'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 21:36:35'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:33:47'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:32:46'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:31:46'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:30:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:29:40'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:28:52'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:28:38'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '4',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:28:32'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:27:37'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '6',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:27:36'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:18:31'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:18:30'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:17:32'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:11:14'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:11:05'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:09:54'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:09:41'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:09:41'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:07:10'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:07:02'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:06:49'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 20:06:49'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:40:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:39:42'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:37:45'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:37:44'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:37:41'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:37:41'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:37:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:37:14'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:35:44'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:33:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:32:42'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:31:55'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:28:55'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:27:54'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:26:55'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:25:51'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:24:50'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:23:48'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:12:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:11:42'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 19:11:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 16:51:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 16:48:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 16:19:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 16:16:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 16:13:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 14:56:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 14:53:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 08:59:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 08:56:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 08:53:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 08:50:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-8 03:46:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 21:01:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 20:58:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 20:36:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 20:29:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 18:06:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 16:47:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 16:44:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 15:44:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 15:29:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 13:05:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 10:33:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 06:34:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 06:29:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-7 06:27:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 23:38:11'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 22:33:50'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 22:32:12'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 22:30:36'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 22:26:27'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 22:24:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 22:24:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 20:11:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 20:08:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 18:47:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 16:23:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 16:10:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 15:13:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 14:56:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 13:14:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 13:11:43'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 12:13:58'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 12:11:55'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 12:10:14'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 12:09:03'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '3',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 12:07:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 10:59:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 09:15:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 09:11:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 07:04:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 05:49:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-6 04:21:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 20:56:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 20:31:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 20:28:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 20:03:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 20:00:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 19:57:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 19:53:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 19:50:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 19:47:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 19:43:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 19:40:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 18:50:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 18:47:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 18:42:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 18:40:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 18:37:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 18:08:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 17:46:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 16:31:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 16:08:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 15:58:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 15:55:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 15:51:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 15:22:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 14:23:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 14:15:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 14:10:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 14:09:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 14:06:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 14:06:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 14:03:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 13:22:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 13:04:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 13:01:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 12:56:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 12:50:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 12:47:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 12:42:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 12:38:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 12:35:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 11:21:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 11:18:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 11:12:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 10:33:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 09:29:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 09:26:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 09:23:25'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 07:31:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 07:00:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 06:18:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 06:12:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 02:51:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 02:48:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-5 02:45:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-4 20:21:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-4 15:38:03'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-4 12:11:54'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-4 12:11:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 23:44:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 23:41:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:35:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:21:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:17:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:12:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:11:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:08:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:03:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 21:00:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 20:30:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 20:27:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 20:24:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 20:17:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 19:11:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 19:07:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 19:04:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 19:00:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 18:56:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 18:53:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 18:44:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 18:41:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 18:05:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 18:02:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 17:59:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 17:55:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 17:51:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 17:46:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 17:42:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 17:10:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 16:45:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 16:42:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 16:11:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 16:07:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 15:58:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 15:49:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 13:42:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 13:39:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 13:35:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 12:54:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 09:56:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 04:50:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 04:50:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 04:29:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 04:09:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-3 03:23:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 22:42:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 22:17:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 22:13:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 22:10:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 22:07:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 21:44:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 21:14:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 20:03:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 20:00:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 18:33:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 18:30:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 18:12:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 18:09:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 17:50:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 17:42:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 17:40:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 17:16:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 16:15:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 15:56:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 15:52:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 15:49:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 15:08:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 13:08:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 11:53:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 11:50:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 11:36:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 11:20:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 10:26:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 10:01:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 09:58:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 09:54:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 09:39:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 09:36:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 09:31:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 07:37:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 06:17:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 06:01:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 05:32:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 05:28:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 03:12:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-2 01:15:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 23:00:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 22:56:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 22:46:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 22:43:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 22:40:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 22:36:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 22:29:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 22:24:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 20:34:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 20:31:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 20:28:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 20:22:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:52:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:45:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:42:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:40:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:39:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:39:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:32:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:27:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:24:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:21:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:04:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 19:04:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 18:22:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 17:54:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 16:02:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 14:47:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 14:09:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 13:19:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 10:49:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 09:56:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 09:50:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 09:47:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 09:18:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 09:13:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 09:10:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 08:06:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 03:15:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 03:12:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 02:17:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 02:12:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 02:09:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 01:52:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 01:49:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 01:37:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 01:34:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-3-1 01:25:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 22:24:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 22:21:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 22:18:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 22:14:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 22:11:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 19:46:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 19:46:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 19:46:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 18:52:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 14:29:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 14:26:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 14:23:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 13:54:48'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 11:26:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 07:10:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 07:04:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 07:00:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 06:57:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 06:54:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 06:51:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 06:48:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 06:41:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-29 00:20:07'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 23:45:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 23:28:05'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 23:04:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 22:56:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 22:53:01'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 22:31:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 16:19:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 09:25:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-28 04:03:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 18:19:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 18:06:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 17:33:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 17:29:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 16:25:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 16:22:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 15:35:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-27 10:56:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 18:18:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 18:15:31'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 17:23:05'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 17:22:48'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 17:22:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 14:28:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 13:56:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 13:05:20'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 11:25:44'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 11:25:37'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 11:25:28'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 09:53:51'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 09:53:40'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 09:53:31'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 09:14:36'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 09:14:36'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 09:14:36'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 09:14:36'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 03:08:55'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 03:07:49'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 03:06:51'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 02:59:45'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 02:05:27'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 02:05:25'
            ],
            [
                'appId' => 'com-YourCompany-ADS_CORM_PRO',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 02:01:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-26 00:15:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 22:47:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 22:47:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 21:19:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 19:20:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 19:17:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 19:14:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 18:43:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 16:53:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 16:49:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 15:12:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 15:09:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 15:05:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 14:27:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 14:18:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 12:06:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 12:06:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 11:51:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 11:24:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 11:21:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 11:19:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 11:18:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 11:16:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 09:22:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 08:55:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 08:55:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 08:44:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 08:40:44'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 07:41:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 06:02:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 05:59:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 05:56:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-25 05:52:58'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 21:48:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 21:46:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 20:55:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 20:55:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 20:50:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 20:21:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 20:18:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 20:16:04'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 19:41:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 19:39:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 19:35:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 18:14:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 17:11:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 17:08:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 17:06:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 16:41:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 16:06:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:47:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:45:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:41:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:38:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:34:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:29:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:26:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:14:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:14:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:14:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:10:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:07:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:04:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 15:00:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 14:53:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 14:38:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 14:34:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 13:20:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 13:17:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 13:13:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 13:10:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 13:07:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 13:03:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 13:00:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 12:56:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 12:53:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 10:42:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 09:42:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 04:25:28'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 00:26:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 00:25:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 00:22:13'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 00:04:23'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-24 00:03:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 23:44:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 23:37:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 22:56:14'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 21:58:12'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 21:44:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 21:06:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 20:49:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 19:38:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 19:35:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 19:32:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 18:48:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 17:11:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 17:08:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 16:21:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 16:17:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 14:22:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 12:07:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 11:09:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 08:20:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 08:08:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 08:05:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 07:43:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 04:52:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 04:49:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 04:45:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 04:20:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 04:17:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 04:14:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 03:58:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 03:27:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 03:23:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 01:27:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-23 00:23:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:47:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:43:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:37:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:13:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:13:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:11:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:10:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:10:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:09:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:07:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 22:06:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 20:43:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 20:40:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 20:37:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 20:31:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 19:20:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 19:16:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 19:13:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 19:09:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 18:17:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 18:14:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 18:00:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 17:48:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 17:45:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 15:56:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 15:50:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 15:22:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 15:08:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 15:08:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 15:05:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 13:58:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 01:50:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-22 01:20:24'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 22:36:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 21:52:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 21:49:39'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:19:29'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:19:29'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:18:31'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:18:31'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:18:30'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:18:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:17:31'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:17:31'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:17:29'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:17:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:16:31'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:16:30'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:16:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:16:27'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:15:31'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:15:30'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:15:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:15:27'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:14:30'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:14:29'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:14:27'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:14:26'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:13:29'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:13:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:13:27'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:13:26'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:13:19'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:12:17'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:11:16'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:10:18'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:09:15'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:08:15'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:07:17'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:06:14'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:05:13'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:04:13'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:03:14'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:03:12'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:02:12'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:01:13'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 20:00:11'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:59:10'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:58:12'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:57:10'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:56:09'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:55:43'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:55:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:55:23'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:55:15'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:55:12'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:55:11'
            ],
            [
                'appId' => 'com-example-adv_test',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:46:25'
            ],
            [
                'appId' => 'com-example-adv_test',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:46:22'
            ],
            [
                'appId' => 'com-example-adv_test',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:43:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:23:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:21:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:18:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:17:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:14:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 19:11:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:56:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:51:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:48:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:34:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:27:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:20:59'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:20:26'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:20:23'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:20:21'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:20:21'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:20:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:17:38'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:13:37'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:13:33'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:13:27'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:13:27'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 18:13:26'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:47:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:44:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:37:49'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:09:25'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:04:05'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:04:03'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:04:02'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:04:02'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:03:04'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:03:03'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:03:02'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:03:02'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:02:04'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:02:02'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:02:02'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:02:01'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:00:34'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:00:33'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:00:33'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:00:31'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:00:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 17:00:28'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 16:59:35'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 16:59:33'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 16:56:37'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 16:56:26'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 16:55:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 13:49:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 13:31:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 13:28:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 13:25:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 13:22:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 12:32:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 12:29:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 11:58:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 11:55:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 11:51:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 11:48:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 11:45:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 11:42:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 11:39:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 08:27:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 07:56:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 06:47:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 05:48:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-21 05:45:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 21:38:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 21:38:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 20:18:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:55:22'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:47:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:44:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:44:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:40:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:36:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:33:26'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:26:50'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:26:08'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:25:39'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:23:59'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:09:32'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:09:03'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:08:57'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:08:55'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:06:24'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:06:05'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:06:03'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 19:05:53'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 18:49:59'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 18:49:39'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 18:43:40'
            ],
            [
                'appId' => 'com-adscore-pro',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 18:38:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 18:07:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 17:47:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:53:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:48:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:45:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:42:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:33:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:25:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:22:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:22:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 15:15:17'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 09:11:40'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 08:02:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 07:42:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 05:21:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 05:02:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 04:58:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 04:14:36'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-20 00:16:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 23:31:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 23:28:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 19:47:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 19:24:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:43:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:40:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:15:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:12:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:11:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:08:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:05:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 18:01:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 16:49:20'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 16:42:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 15:46:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 15:42:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 15:39:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 15:00:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 11:35:12'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 06:17:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:53:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:50:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:47:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:44:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:40:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:37:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:34:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 05:26:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 02:57:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 02:48:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 02:45:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 02:41:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 02:34:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 02:31:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:42:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:39:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:18:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:15:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:12:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:09:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:04:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 01:00:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:51:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:47:41'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:47:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:43:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:41:43'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:40:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:37:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:36:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:33:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:29:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:23:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-19 00:04:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 23:53:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 23:47:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 20:19:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 20:16:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 18:22:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 18:19:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 18:16:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 18:13:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 17:57:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 17:51:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 15:18:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 13:56:30'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 13:33:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 13:30:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 12:11:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 12:08:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 12:08:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 11:46:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 11:43:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 11:21:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 11:17:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 11:14:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:57:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:56:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:54:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:52:55'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:51:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:48:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:47:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:44:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:44:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:41:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 10:41:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 09:08:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 09:06:03'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-18 00:54:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 20:01:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 19:58:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 19:55:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 19:52:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 19:23:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:52:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:38:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:35:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:32:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:28:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:22:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:16:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 18:02:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 17:44:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 17:37:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 16:15:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 16:09:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 15:38:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 15:32:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 15:25:37'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 15:11:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 14:21:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 13:39:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 13:36:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 13:35:30'
            ],
            [
                'appId' => 'com-YourCompany-CalRTX',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 08:43:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 07:07:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 06:08:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-17 02:46:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 20:16:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 20:13:18'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 16:43:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 16:38:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 15:15:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 14:34:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 13:03:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 13:00:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 12:56:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 11:57:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 09:05:50'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 02:53:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 02:02:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 01:59:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-16 01:56:00'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 22:06:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 19:57:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 19:15:47'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 19:12:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 19:09:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 19:06:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 19:03:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 19:00:19'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 18:57:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 18:54:07'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 18:01:54'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 17:46:57'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 17:21:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 16:52:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 16:30:28'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 15:47:06'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 14:44:59'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 14:41:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 14:02:12'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 14:02:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 13:58:32'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 13:54:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 13:50:48'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 13:47:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 12:02:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 10:55:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 10:52:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-15 00:09:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 23:52:35'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 22:37:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 22:33:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 21:39:27'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 21:36:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 21:18:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 16:00:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 15:02:23'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 13:25:24'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 12:54:05'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 12:34:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 10:56:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 09:14:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 01:43:42'
            ],
            [
                'appId' => 'ama.the.king.com',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-14 01:11:40'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 23:56:38'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 22:57:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 20:45:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 20:12:36'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 19:47:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 17:39:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 17:39:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 17:39:08'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 17:09:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 16:20:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 10:18:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 09:51:51'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 09:48:42'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 09:03:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-13 05:13:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 23:42:39'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 20:20:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 19:35:11'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 19:07:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 18:08:10'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 17:41:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 17:09:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 17:06:13'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 11:19:58'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 10:33:01'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 08:25:56'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 06:00:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 05:57:23'
            ],
            [
                'appId' => 'ama.the.king.com',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 04:21:36'
            ],
            [
                'appId' => 'ama.the.king.com',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-2-12 04:21:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 20:17:21'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 20:13:53'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 20:10:17'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 17:04:31'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 16:57:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 16:04:44'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 14:27:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 14:19:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 13:27:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 12:35:49'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 12:32:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 12:10:14'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 12:07:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 10:25:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 10:22:20'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 10:19:15'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-11 07:02:59'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 22:14:56'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 22:14:51'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 19:16:33'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 18:56:29'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 18:27:38'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 13:53:56'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 12:37:53'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 12:37:46'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 11:28:02'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 07:52:15'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 07:36:32'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-10 01:06:52'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 23:36:12'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 23:32:26'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 21:21:52'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 21:18:39'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 15:29:44'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 15:28:19'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 15:26:00'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 14:18:23'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 14:15:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 14:08:45'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 14:05:31'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 14:00:57'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 12:38:34'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 12:18:26'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 09:32:12'
            ],
            [
                'appId' => 'com-dude-vibor',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 01:55:16'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-9 01:44:33'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 19:37:04'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 15:09:46'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 13:03:11'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 13:02:05'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 13:00:35'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 12:59:06'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 12:51:55'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 12:50:59'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 12:50:42'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 12:50:09'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 10:28:25'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '1',
                'createdAt' => '2024-2-8 10:25:06'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '1',
                'timesCalled' => '83',
                'createdAt' => '2024-2-2 21:58:58'
            ],
            [
                'appId' => 'com-vFredov-PYATERKAFIGHT',
                'appType' => '1',
                'timesCalled' => '2',
                'createdAt' => '2024-2-2 21:10:24'
            ],
            [
                'appId' => 'com-gamestudiokg-spider',
                'appType' => '1',
                'timesCalled' => '71',
                'createdAt' => '2024-1-31 15:55:23'
            ],
            [
                'appId' => 'com-dude-vibor',
                'appType' => '1',
                'timesCalled' => '30',
                'createdAt' => '2024-1-30 06:39:06'
            ],
            [
                'appId' => 'com-dude-vibor',
                'appType' => '99',
                'timesCalled' => '4',
                'createdAt' => '2024-1-30 01:50:42'
            ],
            [
                'appId' => 'com-YoungPlayersClub-EndllesNight',
                'appType' => '99',
                'timesCalled' => '7',
                'createdAt' => '2024-1-29 11:14:54'
            ],
            [
                'appId' => 'com-horizonhavengames-starstream',
                'appType' => '2',
                'timesCalled' => '18',
                'createdAt' => '2024-1-27 16:10:38'
            ],
            [
                'appId' => 'com-StanislavM-Bomber',
                'appType' => '1',
                'timesCalled' => '14',
                'createdAt' => '2024-1-18 23:38:41'
            ],
            [
                'appId' => 'com-YourCompany-CalRTX',
                'appType' => '99',
                'timesCalled' => '15',
                'createdAt' => '2024-1-18 15:50:36'
            ],
            [
                'appId' => 'com-VOIDROSE-DefaultRunner',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-1-14 22:48:41'
            ],
            [
                'appId' => 'com-YourCompany-ADSCoreLite',
                'appType' => '99',
                'timesCalled' => '1',
                'createdAt' => '2024-1-14 22:27:36'
            ],
            [
                'appId' => 'com-example-nativecpptest',
                'appType' => '99',
                'timesCalled' => '7',
                'createdAt' => '2024-1-14 19:25:02'
            ],
        ];

        $this->batchInsert('ads_stats', [
            'appId',
            'appType',
            'timesCalled',
            'createdAt',
        ], $insert);


        $this->db->createCommand()->createView('vads_stats','
            SELECT
                row_number() OVER(
                   ORDER BY appId
                ) AS id,
                appId,
                appType,
                SUM(timesCalled) AS sumTimesCalled,
                MAX(createdAt) AS firstCreatedAt,
                MIN(createdAt) AS lastCreatedAt
            FROM `ads_stats`
            GROUP BY appId, appType
        ')->execute();
    }

    /**
     * {@inheritdoc}
     * @throws \yii\db\Exception
     */
    public function safeDown()
    {
        echo "m240211_115918_ads_statistics cannot be reverted.\n";

        // drops foreign key for table `category`
        $this->dropIndex(
            'idx-ads-statistics-appid',
            'ads_stats'
        );

        $this->db->createCommand()->dropView('vads_stats')->execute();

        $this->dropTable('ads_stats');

        return false;
    }
}
