<?php

use yii\db\Migration;

/**
 * Class m240413_145911_ads_users
 */
class m240413_145911_ads_users extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $tableOptions = null;

        $this->createTable('ads_users', [
            'id' => $this->primaryKey(),
            'email' => $this->string()->notNull(),
            'username' => $this->string()->notNull(),
            'password' => $this->string()->notNull(),
            'status' => $this->smallInteger()->notNull()->defaultValue(0),
            'activateToken' => $this->string()->notNull(),
            'authKey' => $this->string(),
            'licenseToken' => $this->string(),
            'createdAt' => $this->dateTime()->notNull()->defaultExpression('CURRENT_TIMESTAMP'),
            'isDeleted' => $this->smallInteger()->notNull()->defaultValue(0),
        ], $tableOptions);

        // creates index
        $this->createIndex(
            'idx-ads-users-username',
            'ads_users',
            'username'
        );

        $insert = [
            [
                'email' => 'kashak233@gmail.com',
                'username' => 'kashak23',
                'password' => '$2y$13$tQpemcm82vblzIyjU8yzVOoOv699BOdGAKEyu.PiXu/wQ/rMwutAu',
                'status' => '1',
                'activateToken' => 'vk5NroFragwqtYE7dPfCXNTiQPXKZoy7',
                'authKey' => 'xMrY7uEa9X2GpdUo_pWdyJTAZCijuHvp',
                'createdAt' => '2024-5-6 19:00:33'
            ]
        ];

        $this->batchInsert('ads_users', [
            'email',
            'username',
            'password',
            'status',
            'activateToken',
            'authKey',
            'createdAt',
        ], $insert);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m240413_145911_ads_users cannot be reverted.\n";

        // drops foreign key for table `category`
        $this->dropIndex(
            'idx-ads-users-username',
            'ads_users'
        );
        $this->dropTable('ads_users');

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m240413_145911_ads_users cannot be reverted.\n";

        return false;
    }
    */
}
